package com.green.mapper;

import java.util.List;

import com.green.domain.LoanDTO;

public interface LoanMapper {
	public void loaninsert(LoanDTO loan);
	public List<LoanDTO> loanSerial(String serial);
	public LoanDTO loanLat(String serial);
}

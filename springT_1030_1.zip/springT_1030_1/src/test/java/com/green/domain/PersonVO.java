package com.green.domain;

public class PersonVO {
	int no;
	String name;
	String personId;
	String address;
	String tel;
	int brothers;
	String father;
	int age;
	public PersonVO() {};
	public PersonVO(int no, String name, String personId, String address, String tel, int brothers, String father) {
		super();
		this.no = no;
		this.name = name;
		this.personId = personId;
		this.address = address;
		this.tel = tel;
		this.brothers = brothers;
		this.father = father;
	}
	public int getNo() {
		return no;
	}
	public PersonVO setNo(int no) {
		this.no = no;
		return this;
	}
	public String getName() {
		return name;
	}
	public PersonVO setName(String name) {
		this.name = name;
		return this;
	}
	public String getPersonId() {
		return personId;
	}
	public PersonVO setPersonId(String personId) {
		this.personId = personId;
		return this;
	}
	public String getAddress() {
		return address;
	}
	public PersonVO setAddress(String address) {
		this.address = address;
		return this;
	}
	public String getTel() {
		return tel;
	}
	public PersonVO setTel(String tel) {
		this.tel = tel;
		return this;
	}
	public int getBrothers() {
		return brothers;
	}
	public PersonVO setBrothers(int brothers) {
		this.brothers = brothers;
		return this;
	}
	public String getFather() {
		return father;
	}
	public PersonVO setFather(String father) {
		this.father = father;
		return this;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	
}
